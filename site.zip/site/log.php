<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="vm.css">
    <title>User Registration</title>
    <script>
        function checkPassword() {
            var password1 = document.getElementById("password1").value;
            var password2 = document.getElementById("password2").value;

            if (password1 !== password2) {
                alert("Passwords do not match");
                return false;
            }
            return true;
        }
    </script>
</head>
<body style="background-image: url(pic3.jpg); background-repeat: no-repeat; background-size: cover;">
<header>
    <h1>Регистрация</h1>
</header>

<form action="connection.php" method="post" onsubmit="return checkPassword()">
    <label for="email">Email:</label>
    <input type="text" id="email" name="email" placeholder="email" required><br>

    <div>
        <label for="password1">Парола:</label>
        <input type="password" id="password1" name="password" placeholder="password" required><br>

        <label for="password2">Повторна Парола</label>
        <input type="password" id="password2" name="password" placeholder="password" required><br>
    </div>

    <label for="firstName">Име:</label>
    <input type="text" id="firstName" name="firstName" placeholder="firstName" required><br>
    
    <label for="lastName">Фамилия</label>
    <input type="text" id="lastName" name="lastName" placeholder="lastName" required><br>

    <input type="submit" value="Register">
</form>
<button onclick="window.location.href='vmLogin.html';">Login</button>
<footer>
    <!-- <button style="border-radius: 20px; background-color: rgb(139, 17, 215); color: white;" onclick="location.href='VacationManager.html';">
        <p></p>Връщане към началната страница<p></p>
    </button> -->
</footer>
</body>
</html>
