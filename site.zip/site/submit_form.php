<?php
// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Include your database connection file
    $conn = new mysqli('localhost','root','','vmanager'); // Make sure to replace with the actual filename

    // Get form data
    $leaveType = $_POST["leave-type"];
    $startDate = $_POST["start-date"];
    $endDate = $_POST["end-date"];
    $sender = $_POST["sender"];

    // Insert data into the table
    $sql = "INSERT INTO vacation_requests (leave_type, start_date, end_date, sender) 
            VALUES ('$leaveType', '$startDate', '$endDate', '$sender')";

    if ($conn->query($sql) === TRUE) {
        echo "Leave request submitted successfully!";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    // Close the database connection
    $conn->close();
}
?>
