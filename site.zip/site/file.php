<?php
$conn = mysqli_connect("localhost", "root", "", "baligo");
$profile_page_id = $_GET["id"];
$sqlSelect = "SELECT * FROM `users` WHERE `id` = '$profile_page_id'";
$result = $conn -> query($sqlSelect);
$row = $result -> fetch_assoc();
$name = $row["name"];
$lastname = $lastname["lastname"];
$email = $email["email"];

?>