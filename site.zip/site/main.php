<?php
session_start(); // Start the session

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "baligo";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Assuming you have a way to identify the user, for example, a ID
if(isset($_SESSION['ID'])) {
    $ID = $_SESSION['ID']; // replace this with the actual ID

    // Retrieve image content from the database for the specific user
    $result = $conn->query("SELECT profile_pic FROM users WHERE ID = '$ID'");
    if($result){
        $user = $result->fetch_assoc();
        $profile_pic = $user['profile_pic'];
    }else{
        echo "Failed to retrieve profile picture.";
    }
} else {
    echo "No user is logged in.";
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Main Page</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: linear-gradient(to bottom, #f7f7f7, #eaeaea);
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
        }
        .container {
            text-align: center;
            padding: 40px;
            max-width: 600px;
            width: 100%;
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);
        }
        h1 {
            color: #333;
            font-size: 36px;
            margin-bottom: 20px;
            font-weight: bold;
        }
        p {
            color: #666;
            font-size: 18px;
            margin-bottom: 30px;
            line-height: 1.6;
        }
        .button {
            display: inline-block;
            padding: 12px 24px;
            font-size: 18px;
            cursor: pointer;
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 30px;
            text-decoration: none;
            transition: background-color 0.3s;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);
        }
        .button:hover {
            background-color: #0056b3;
        }
        #logo {
            width: 200px;
            height: 200px;
            margin-bottom: 50px;
            border-radius: 50%;
            object-fit: cover; 
            border: 5px solid #fff;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);
            cursor: pointer;
        }
        #friends {
            margin-top: 30px;
            font-size: 20px;
        }
    </style>
</head>
<body>
<div class="container">
        <form action="upload.php" method="post" enctype="multipart/form-data">
            <input type="file" name="profilePic" id="fileInput" accept="image/*" style="display: none;">
            <label for="fileInput">
                <img id="logo" src="data:image/jpeg;base64,<?php echo base64_encode($profile_pic); ?>" alt="Website Logo">
            </label>
            <input type="submit" value="Upload Image" name="submit">
        </form>
        <h1>Welcome to Our Website</h1>
        <p>This is a place where you can explore memories captured in photos and connect with friends.</p>
        <p>What would you like to do?</p>
        <a href="photos.html" class="button">View Photos</a>
        <button class="button" id="findFriends">Friends</button>
        <div id="friends"></div>
    </div>
   <script>const friendNames = ["John", "Emily", "Michael", "Sophia", "David", "Emma", "James", "Olivia", "Daniel", "Ava"];
        function displayRandomFriends() {
            const friendsContainer = document.getElementById('friends');
            friendsContainer.innerHTML = '';
            const shuffledNames = friendNames.sort(() => Math.random() - 0.5);
            const randomNames = shuffledNames.slice(0, 3); 
            randomNames.forEach(name => {
                const friendElement = document.createElement('p');
                friendElement.textContent = name;
                friendsContainer.appendChild(friendElement);
            });
        }function handleFileSelect(event) {
            const file = event.target.files[0];
            const reader = new FileReader();
            reader.onload = function (e) {
                const logoImage = document.getElementById('logo');
                logoImage.src = e.target.result;
            };reader.readAsDataURL(file);
        }document.getElementById('findFriends').addEventListener('click', displayRandomFriends);
        document.getElementById('fileInput').addEventListener('change', handleFileSelect);
    </script>
</body>
</html>
