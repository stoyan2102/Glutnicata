﻿<!DOCTYPE html>
<html>
<head>
    <title>12Г</title>
    <link rel="stylesheet" href="../Style.css">
</head>
<body>
   <div class="profile_container">
      <div class="profile_container_left">
         <img src="profile_img.jpg" class="profile_img">
         <div class="btn_container">
            <button onclick="">Приятели</button>
            <button onclick="">Снимки</button>
            <button onclick="">Изход</button>
         </div>
      </div>
      <div class="profile_container_right">
         <p class="name">Емил Стоянов</p>
         <p class="title">Описание</p>
         <p class="description">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas quis enim a massa efficitur elementum quis eget felis. Ut id est aliquam, rhoncus elit ut, pellentesque dolor. Mauris mattis efficitur augue at scelerisque. Sed molestie a erat sed bibendum. Suspendisse porta nec odio ac porta. Vestibulum auctor metus ac ante semper lacinia. Nullam iaculis dolor eget aliquet consequat.</p>
         <p class="description">Suspendisse auctor fringilla lorem, eu pulvinar sem tincidunt quis. Morbi ornare blandit laoreet. Praesent vel mauris in diam faucibus dictum id eu ante. Fusce auctor purus ex, quis congue lacus mattis sed. Ut facilisis justo orci, imperdiet laoreet leo faucibus id. Nulla a pharetra arcu. Interdum et malesuada fames ac ante ipsum primis in faucibus. Quisque suscipit, nisl sed suscipit blandit, magna turpis pulvinar tellus, a ullamcorper eros diam a leo. Quisque lobortis aliquam metus. Fusce in metus sodales, ultrices orci fringilla, ultrices ligula. Proin commodo diam varius vehicula efficitur. Fusce eget velit quis risus pretium lobortis. Ut in facilisis quam, non viverra nunc. Suspendisse hendrerit accumsan purus, eu bibendum risus tempor vitae.</p>
         <p class="description">Cras a laoreet ex, eget tincidunt sapien. Mauris sem nibh, posuere vitae arcu vitae, sagittis tristique erat. Maecenas dapibus sodales lectus, ac rhoncus tortor semper a. In eget tortor vel turpis interdum finibus. Donec gravida pellentesque lorem sit amet sagittis. Integer vitae dignissim tellus. Maecenas dapibus fringilla leo in semper. Vivamus rhoncus, turpis sit amet rutrum imperdiet, dolor orci lobortis nisl, vitae luctus risus nisi vitae nulla. Nunc id tristique urna. Phasellus sed faucibus elit, ut finibus nisl. Duis est orci, aliquet vitae euismod non, feugiat a sem. Aenean consequat sapien sit amet elit consectetur, vel commodo velit porttitor.</p>
      </div>
   </div>
</body>
</html>