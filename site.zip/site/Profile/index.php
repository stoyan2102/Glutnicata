﻿<!DOCTYPE html>
<html>
<head>
    <title>12v</title>
    <link rel="stylesheet" href="Style.css">
</head>
<body>
   <form method="post" class="register">
      <p class="register_label">Log - in</p>
      <input name="email" type="text" class="input_text" placeholder="E-mail">
      <input name="password" type="password" class="input_text" placeholder="Парола" min="8">
      <input name="submit" type="submit" class="input_submit" placeholder="Вход">
      <a href="registration">Регистрирай се</а>
      <p id="err_p1"></p>
      <p id="err_p2"></p>
      <?php
         error_reporting(0);
         if(isset($_POST["submit"])){
            $conn = mysqli_connect("localhost", "root", "", "12v");

            $email = $_POST["email"];
            $password = md5($_POST["password"]);
            
            $sqlSelect = "SELECT `e-mail` FROM `users` WHERE `e-mail` = '$email' AND `password` = '$password'";
            $result = $conn->query($sqlSelect);
            $rows = mysqli_num_rows($result);
            //Проверка за потребител
            if($rows > 0){
                echo "
                    <script>
                        window.location.assign('profile');
                    </script>
                ";
            }

            if(!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                echo '
                <script>
                    document.getElementById("err_p1").innerHTML = "*Въведете валидна електронна поща";
                    document.getElementById("err_p1").style.display = "block";
                </script>
                ';
            }
            if($password == ""){
                echo '
                <script>
                    document.getElementById("err_p2").innerHTML = "*Въведете парола";
                    document.getElementById("err_p2").style.display = "block";
                </script>
                ';
            }
            if($reTypePassword == ""){
                echo '
                <script>
                    document.getElementById("err_p3").innerHTML = "*Повторете паролата";
                    document.getElementById("err_p3").style.display = "block";
                </script>
                
                ';
            }
            else if($reTypePassword != $password){
                echo '
                <script>
                    document.getElementById("err_p3").innerHTML = "*Паролите не съвпадат";
                    document.getElementById("err_p3").style.display = "block";
                </script>
                ';
            }
         }
      ?>
   </form>
</body>
</html>