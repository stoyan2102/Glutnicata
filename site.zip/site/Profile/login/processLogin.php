<?php
    session_start();
    if(isset($_POST['login'])){
        $email = $_POST['e-mail'];
        $password = $_POST['password'];
        $rempass = bin2hex($_POST['password']);
        include '../dbconn.php';

        if(empty($email)){
            header("Location: index.php");
        }
        if(empty($password)){
            header("Location: index.php");    
        }

        $sql = "SELECT * FROM users_login WHERE email ='$email' AND password = '$password'";
        $result = mysqli_query($conn, $sql);

        if(mysqli_num_rows($result)>0){
            $row = mysqli_fetch_assoc($result);
            $result1 = mysqli_query($conn, "SELECT * FROM users_info WHERE id = '".$row['id']."'");
            $row1 = mysqli_fetch_assoc($result1);
            $_SESSION['user_name']=$row['email'];
            setcookie ("id",$row['id'],time()+ 3600 , "/");
            $_SESSION['first_name']=$row1['first_name'];
            $_SESSION['last_name']=$row1['last_name'];
            $_SESSION['password']=$row['password'];
            
            if($row1['role']=='T'){
                setcookie("isTrainer", "1", time() + 3600 , "/");
                $trainerEmail = "SELECT trainers_table.id FROM users_login INNER JOIN trainers_table ON users_login.email=trainers_table.email WHERE trainers_table.email='$email'";
                $resultTrainer = mysqli_query($conn, $trainerEmail);
                if(mysqli_num_rows($resultTrainer)>0){
                    $row2 = mysqli_fetch_assoc($resultTrainer);
                    $t_id = $row2['id'];
                    setcookie("t_id", $t_id, time()+ 3600 , "/");
                }
            } elseif ($row1['role']=='A') {
                setcookie("admin", "1", time()+ 3600 , "/");
            }

            if(!empty($_POST["remember"])) {
                setcookie("remember",$_SESSION['user_name'], time()+36000 , "/");
                setcookie ("password", bin2hex($password),time()+ 36000 , "/");
            } 
            header("Location: ../client_panel");
            exit();
                
        } else{
            setcookie ("incorrect","0",time()+ 3600 , "/");
            header("Location: index.php");
        }
    } else{
        header("Location:../index.php");
    }
?>