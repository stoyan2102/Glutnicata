<?php
    if(isset($_COOKIE['id'])){
        header("Location: ../index.php");
    }
    if(isset($_COOKIE["incorrect"])){
        setcookie ("incorrect","0",time()- 3600, "/");
    }
?>
<!DOCTYPE html>
    <html lang="en">
    <?php include "../_includers/head.php"?>
    <body>
        <section class="navigation">
            <?php include "../_includers/navmenu.php"?>
            
            <div class="loginForm" id="loginForm">
                <form action="processLogin.php" method="post">
                    <h1>Влезте в акаунт</h1>
                        
                    <label id = 'incorrectPass'></label>

                    <p style="padding-top: 5px;">E-mail</p>
                    <input type="text" name="e-mail" id = "email" placeholder="Въведи e-mail">

                    <p>Парола:</p>
                    <input type="password" id = "password" name="password" placeholder="Въведи парола">

                    <?php
                        if(isset($_COOKIE['remember'])){
                            echo 
                            '<script>
                                document.getElementById("email").value="'.hex2bin($_COOKIE['remember']).'";
                                document.getElementById("password").value="'.hex2bin($_COOKIE['password']).'";
                            </script>';
                        }
                    ?>

                    <label id="checkboxLabel"for="checkbox">Запомни ме</label>
                    <input class="checkbox" type="checkbox" name="remember">

                    <div class="buttonform">
                        <button class="loginButton" type="submit" name="login">Влез</button>
                    </div>

                    <div class="forgotenpass">
                        <a href="../forgoten_password">Забравена парола</a>
                    </div>

                    <?php
                        if(isset($_COOKIE["incorrect"])){
                            echo 
                            "<script>
                                document.getElementById('incorrectPass').style.color='darkred';
                                document.getElementById('incorrectPass').style.marginLeft='81px';
                                document.getElementById('incorrectPass').innerHTML='Грешен имейл или парола!';
                                document.getElementById('loginForm').style.height='320px'
                            </script>";
                        }
                    ?>
                </form>
            </div>
        </section>
    </body>

    <?php include "../_includers/footer.php"?>
    <?php include "../_includers/scroll_script.php"?>
</html>