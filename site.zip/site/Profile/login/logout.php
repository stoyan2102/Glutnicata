<?php
    session_start();
    setcookie("e-mail", "", time() - 3600 , "/");
    setcookie("id", "", time() - 3600 , "/");
    setcookie("t_id", "", time() - 3600 , "/");
    setcookie("isTrainer", "", time() - 3600 , "/");
    setcookie("admin", "", time() - 3600 , "/");
    header("Location: ../");
    session_destroy();
    exit();
?>