<!DOCTYPE html>
<html>
<head>
    <title>12в</title>
    <link rel="stylesheet" href="../Style.css">
</head>
<body>
   <form method="post" class="register">
      <p class="register_label">Регистрация</p>
      <input name="email" type="text" class="input_text" placeholder="E-mail">
      <input name="password" type="password" class="input_text" placeholder="Парола" min="8">
      <input name="reTypePassword" type="password" class="input_text" placeholder="Повторете паролата" min="8">
      <input name="name" type="text" class="input_text" placeholder="Име">
      <input name="lastname" type="text" class="input_text" placeholder="Фамилия">
      <input name="submit" type="submit" class="input_submit" placeholder="Регистрирай ме">
      <p id="err_p1"></p>
      <p id="err_p2"></p>
      <p id="err_p3"></p>
      <p id="err_p4"></p>
      <p id="err_p5"></p>
      <?php
         if(isset($_POST["submit"])){
            $conn = mysqli_connect("localhost", "root", "", "12v");

            $name = $_POST["name"];
            $lastname = $_POST["lastname"];
            $password = $_POST["password"];
            $reTypePassword = $_POST["reTypePassword"];
            $email = $_POST["email"];
            $name = $_POST["name"];
            $lastname = $_POST["lastname"];
            
            $sqlSelect = "SELECT `e-mail` FROM `users` WHERE `e-mail` = '$email'";
            $result = $conn->query($sqlSelect);
            $rows = mysqli_num_rows($result);
            //Проверка за потребител
            if($password == $reTypePassword && $rows == 0){
               $password = md5($password);
               $sql = "INSERT INTO `users`(`id`, `e-mail`, `password`, `name`, `lastname`, `added_date`) VALUES (NULL,'$email','$password','$name','$lastname', current_timestamp())";
               $conn -> query($sql);
               echo "
                   <script>
                       window.location.assign('../index.php');
                   </script>
               ";
            }

            if(!filter_var($email, FILTER_VALIDATE_EMAIL) ) {
                echo '
                <script>
                    document.getElementById("err_p1").innerHTML = "*Въведете валидна електронна поща";
                    document.getElementById("err_p1").style.display = "block";
                </script>
                ';
            }
            if($password == ""){
                echo '
                <script>
                    document.getElementById("err_p2").innerHTML = "*Въведете парола";
                    document.getElementById("err_p2").style.display = "block";
                </script>
                ';
            }
            if($reTypePassword == ""){
                echo '
                <script>
                    document.getElementById("err_p3").innerHTML = "*Повторете паролата";
                    document.getElementById("err_p3").style.display = "block";
                </script>
                ';
            }
            else if($reTypePassword != $password){
                echo '
                <script>
                    document.getElementById("err_p3").innerHTML = "*Паролите не съвпадат";
                    document.getElementById("err_p3").style.display = "block";
                </script>
                ';
            }
            if($name == ""){
                echo '
                <script>
                    document.getElementById("err_p4").innerHTML = "*Въведете име";
                    document.getElementById("err_p4").style.display = "block";
                </script>
                ';
            }
            if($lastname == ""){
                echo '
                <script>
                    document.getElementById("err_p5").innerHTML = "*Въведете фамилия";
                    document.getElementById("err_p5").style.display = "block";
                </script>
                ';
            }
         }
      ?>
   </form>
</body>
</html>