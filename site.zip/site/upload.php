<?php
session_start(); // Start the session

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "baligo";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if(isset($_POST["submit"])) {
    $check = getimagesize($_FILES["profilePic"]["tmp_name"]);
    if($check !== false) {
        $image = $_FILES['profilePic']['tmp_name'];
        $imgContent = addslashes(file_get_contents($image));

        // Assuming you have a way to identify the user, for example, a ID
        if(isset($_SESSION['ID'])) {
            $ID = $_SESSION['ID']; // replace this with the actual ID

            // Update image content in the database for the specific user
            $update = $conn->query("UPDATE users SET profile_pic = '$imgContent' WHERE ID = '$ID'");
            if($update){
                echo "File uploaded successfully.";
            }else{
                echo "File upload failed, please try again.";
            } 
        } else {
            echo "No user is logged in.";
        }
    }else{
        echo "Please select an image file to upload.";
    }
}
?>
