<?php
$conn = new mysqli('localhost','root','','vmanager');

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if username and password are valid
$user = 'your_username';
$pass = 'your_password';
$sql = "SELECT * FROM users WHERE username = '$user' AND password = '$pass'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // If valid, redirect to new page
    header('Location: newpage.php');
} else {
    echo "Invalid username or password";
}

$conn->close();
?>
