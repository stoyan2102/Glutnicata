<?php
$conn = new mysqli('localhost','root','','vmanager');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password']; // Plain text password

    // Prepare and execute SQL statement
    $stmt = $conn->prepare("SELECT * FROM registration WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();

    if ($user && $user['password'] === $password) {
        // Password is correct, redirect to dashboard
        header("Location: Site.html"); // Adjust the path as needed
        exit();
    } else {
        // Authentication failed
        //echo "Invalid username or password";
        header("Location: vmError.html");
    }
}
?>
