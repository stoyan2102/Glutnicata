<?php
	$TypeVacation = $_POST['TypeVacation'];
    $StartDate = $_POST['StartDate'];
    $FinalDate = $_POST['FinalDate'];
    $Sender = $_POST['Sender'];

	// Database connection
	$conn = new mysqli('localhost','root','','vmanager');
	if($conn->connect_error){
		echo "$conn->connect_error";
		die("Connection Failed : ". $conn->connect_error);
	} else {
		$stmt = $conn->prepare("insert into vacations(TypeVacation, StartDate, FinalDate, Sender) values(?, ?, ?, ?)");
		$stmt->bind_param("sdds", $TypeVacation, $StartDate, $FinalDate, $Sender);
		$execval = $stmt->execute();
		echo $execval;
		 echo "Your request was successfully sent!";
		//header("Location: vmLogin.html");
		$stmt->close();
		$conn->close();
	}
?>