document.addEventListener("DOMContentLoaded", function() {
    var leaveRequestsList = document.getElementById("leave-requests-list");
    var leaveRequestForm = document.getElementById("leave-request-form");
    var deleteButton = document.getElementById("delete-requests-btn");

    // Проверяваме дали има предишно запазени заявки в localStorage
    var storedLeaveRequests = JSON.parse(localStorage.getItem("leaveRequests")) || [];

    // Възстановяваме предишно запазените заявки на страницата
    storedLeaveRequests.forEach(function(request) {
        addLeaveRequest(request.type, request.startDate, request.endDate);
    });

    leaveRequestForm.addEventListener("submit", function(event) {
        event.preventDefault();

        var leaveType = document.getElementById("leave-type").value;
        var startDate = document.getElementById("start-date").value;
        var endDate = document.getElementById("end-date").value;

        addLeaveRequest(leaveType, startDate, endDate);

        // Запазваме текущата заявка в localStorage
        var currentLeaveRequests = JSON.parse(localStorage.getItem("leaveRequests")) || [];
        currentLeaveRequests.push({ type: leaveType, startDate: startDate, endDate: endDate });
        localStorage.setItem("leaveRequests", JSON.stringify(currentLeaveRequests));

        // Изчистваме формата след изпращане на заявка
        leaveRequestForm.reset();
    });

    deleteButton.addEventListener("click", function() {
        // Изтриваме заявките от localStorage
        localStorage.removeItem("leaveRequests");

        // Изчистваме списъка на страницата
        leaveRequestsList.innerHTML = "";
    });

    function addLeaveRequest(type, startDate, endDate) {
        var listItem = document.createElement("li");
        listItem.textContent = `Вид на отпуск: ${type}; Начална дата: ${startDate}; Крайна дата: ${endDate}.`;
        leaveRequestsList.appendChild(listItem);

        // При добавяне на нова заявка, проверяваме позицията на footer-а
        updateFooterPosition();
    }
    // При прокрутка на страницата, проверяваме позицията на footer-а
    window.addEventListener("scroll", updateFooterPosition);
});

// Вашият съществуващ JavaScript код
document.getElementById('open-user-menu-btn').addEventListener('click', function() {
    document.getElementById('user-menu-modal').style.display = 'block';
});

document.getElementById('close-user-menu-btn').addEventListener('click', function() {
    document.getElementById('user-menu-modal').style.display = 'none';
});

window.addEventListener('click', function(event) {
    if (event.target === document.getElementById('user-menu-modal')) {
        document.getElementById('user-menu-modal').style.display = 'none';
    }
});

document.getElementById('open-ekip-menu-btn').addEventListener('click', function() {
    document.getElementById('ekip-menu-modal').style.display = 'block';
});

document.getElementById('close-ekip-menu-btn').addEventListener('click', function() {
    document.getElementById('ekip-menu-modal').style.display = 'none';
});

window.addEventListener('click', function(event) {
    if (event.target === document.getElementById('ekip-menu-modal')) {
        document.getElementById('ekip-menu-modal').style.display = 'none';
    }
});

//--------------------------------------------
document.addEventListener("DOMContentLoaded", function () {
    // Списък с потребители и техните роли (примерни данни)
    const users = [
        { username: "user1", role: "CEO" },
        { username: "user2", role: "Developer" },
        { username: "user3", role: "Developer" },
        { username: "user4", role: "Team Lead" },
        { username: "user5", role: "Team Lead" },
        { username: "user6", role: "Unassigned" },
        // Добавете още потребители и техни роли по необходимост
    ];

    // Функция за показване на потребителите в модалното прозореце
    function displayUsers(filterRole = "all", searchTerm = "") {
        const userList = document.getElementById("user-list");
        userList.innerHTML = ""; // Изчистване на съдържанието преди показване

        users.forEach(user => {
            // Проверка за съвпадение с филтъра и търсачката
            if ((filterRole === "all" || user.role === filterRole) &&
                (user.username.includes(searchTerm) || user.role.includes(searchTerm))) {
                const listItem = document.createElement("li");
                listItem.textContent = `${user.username} - ${user.role}`;
                userList.appendChild(listItem);
            }
        });
    }

 document.getElementById("open-roli-menu-btn").addEventListener("click", function () {
    const modal = document.getElementById("role-menu-modal");
    modal.style.display = "block";

    // Извикване на функцията за показване на ролите
    displayRoleCounts();
});

 // При натискане на бутона "Роли"
 document.getElementById("open-roli-menu-btn").addEventListener("click", function () {
    const modal = document.getElementById("role-menu-modal");
    modal.style.display = "block";
});

// При натискане на бутона за затваряне на модалното прозореце
document.getElementById("close-role-menu-btn").addEventListener("click", function () {
    const modal = document.getElementById("role-menu-modal");
    modal.style.display = "none";
});

window.addEventListener('click', function(event) {
    if (event.target === document.getElementById('role-menu-modal')) {
        document.getElementById('role-menu-modal').style.display = 'none';
    }
});

// Функция за показване на ролите 
function displayRoleCounts(searchTerm = "") {
    const roles = ["CEO", "Developer", "Team Lead", "Unassigned"];
    const roleCountsContainer = document.getElementById("role-counts");

    // Изчистваме предишните роли и бройки
    roleCountsContainer.innerHTML = "";

    roles.forEach(role => {
        const count = users.filter(user => user.role === role).length;
        const roleCountElement = document.createElement("p");
        roleCountElement.textContent = `${role} (${count})`;
        roleCountsContainer.appendChild(roleCountElement);
    });

    // Филтриране на потребителите по роля
    const filteredUsers = users.filter(user => user.role.toLowerCase().includes(searchTerm.toLowerCase()));
    displayUsersInModal(filteredUsers);
}

// Функция за показване на потребителите в модалното прозореце
function displayUsersInModal(users) {
    const userList = document.getElementById("user-list");
    userList.innerHTML = ""; // Изчистване на съдържанието преди показване

    users.forEach(user => {
        const listItem = document.createElement("li");
        listItem.textContent = `${user.username} - ${user.role}`;
        userList.appendChild(listItem);
    });
}

// При зареждане на страницата
displayRoleCounts();
    displayUsers();

    // При промяна на филтъра или търсачката
    document.getElementById("filter").addEventListener("change", function () {
        const filterRole = this.value;
        const searchTerm = document.getElementById("search").value;
        displayUsers(filterRole, searchTerm);
    });

    document.getElementById("search").addEventListener("input", function () {
        const filterRole = document.getElementById("filter").value;
        const searchTerm = this.value;
        displayUsers(filterRole, searchTerm);
    });
});