<?php
	$email = $_POST['email'];
	$password = $_POST['password'];
	$firstName = $_POST['firstName'];
	$lastName = $_POST['lastName'];
	// Database connection
	$conn = new mysqli('localhost','root','','baligo');
	if($conn->connect_error){
		echo "$conn->connect_error";
		die("Connection Failed : ". $conn->connect_error);
	} else {
		$stmt = $conn->prepare("insert into users(email, password, firstName, lastName) values(?, ?, ?, ?)");
		$stmt->bind_param("ssss", $email, $password, $firstName, $lastName);
		$execval = $stmt->execute();
		echo $execval;
		// echo "Registration successfully...";
		header("Location: vmLogin.html");
		$stmt->close();
		$conn->close();
	}
?>