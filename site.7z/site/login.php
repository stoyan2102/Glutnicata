<?php
$conn = new mysqli('localhost','root','','baligo');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'];
    $password = $_POST['password']; // Plain text password

    // Prepare and execute SQL statement
    $stmt = $conn->prepare("SELECT * FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();

    if ($user && $user['password'] === $password) {
        // Password is correct, redirect to dashboard
        header("Location: main.html"); // Adjust the path as needed
        exit();
    } else {
        // Authentication failed
        //echo "Invalid username or password";
        header("Location: vmError.html");
    }
}
?>
